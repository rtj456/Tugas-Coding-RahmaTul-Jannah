document.addEventListener("DOMContentLoaded", function () {
    const productForm = document.getElementById("productForm");
    const productTableBody = document.querySelector("#productTable tbody");

    // Load produk saat halaman dimuat
    loadProducts();

    // Handle form submit untuk menambahkan produk
    productForm.addEventListener("submit", function (e) {
        e.preventDefault();
        const namaProduk = document.getElementById("nama_produk").value;
        const harga = document.getElementById("harga").value;
        const jumlahStok = document.getElementById("jumlah_stok").value;

        fetch("php/add_product.php", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ nama_produk: namaProduk, harga: harga, jumlah_stok: jumlahStok }),
        })
            .then((response) => response.json())
            .then((data) => {
                if (data.success) {
                    alert("Produk berhasil ditambahkan!");
                    loadProducts();
                    productForm.reset();
                } else {
                    alert("Gagal menambahkan produk.");
                }
            });
    });

    // Function untuk memuat daftar produk
    function loadProducts() {
        fetch("php/view_products.php")
            .then((response) => response.json())
            .then((data) => {
                productTableBody.innerHTML = "";
                data.forEach((product) => {
                    const row = `
                        <tr>
                            <td>${product.id_produk}</td>
                            <td>${product.nama_produk}</td>
                            <td>${product.harga}</td>
                            <td>${product.jumlah_stok}</td>
                            <td>
                                <button onclick="editProduct(${product.id_produk})">Edit</button>
                                <button onclick="deleteProduct(${product.id_produk})">Hapus</button>
                            </td>
                        </tr>
                    `;
                    productTableBody.innerHTML += row;
                });
            });
    }

    // Function untuk mengedit stok produk
    window.editProduct = function (id) {
        const newStok = prompt("Masukkan jumlah stok baru:");
        if (newStok !== null && !isNaN(newStok)) {
            fetch("php/update_stock.php", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ id_produk: id, jumlah_stok: parseInt(newStok) }),
            })
                .then((response) => response.json())
                .then((data) => {
                    if (data.success) {
                        alert("Stok berhasil diperbarui!");
                        loadProducts();
                    } else {
                        alert("Gagal memperbarui stok.");
                    }
                });
        } else {
            alert("Input tidak valid.");
        }
    };

    // Function untuk menghapus produk
    window.deleteProduct = function (id) {
        if (confirm("Apakah Anda yakin ingin menghapus produk ini?")) {
            fetch(`php/delete_product.php?id=${id}`, { method: "DELETE" })
                .then((response) => response.json())
                .then((data) => {
                    if (data.success) {
                        alert("Produk berhasil dihapus!");
                        loadProducts();
                    } else {
                        alert("Gagal menghapus produk.");
                    }
                });
        }
    };
});