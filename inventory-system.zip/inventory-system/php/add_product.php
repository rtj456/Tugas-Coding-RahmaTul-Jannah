<?php
require_once "db.php";

$data = json_decode(file_get_contents("php://input"), true);

$nama_produk = $data['nama_produk'];
$harga = $data['harga'];
$jumlah_stok = $data['jumlah_stok'];

$sql = "INSERT INTO Produk (nama_produk, harga) VALUES (:nama_produk, :harga)";
$stmt = $conn->prepare($sql);
$stmt->bindParam(":nama_produk", $nama_produk);
$stmt->bindParam(":harga", $harga);
$stmt->execute();

$id_produk = $conn->lastInsertId();

$sql_stok = "INSERT INTO Stok (id_produk, jumlah_stok) VALUES (:id_produk, :jumlah_stok)";
$stmt_stok = $conn->prepare($sql_stok);
$stmt_stok->bindParam(":id_produk", $id_produk);
$stmt_stok->bindParam(":jumlah_stok", $jumlah_stok);
$stmt_stok->execute();

echo json_encode(["success" => true]);
?>