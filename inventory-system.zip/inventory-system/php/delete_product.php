<?php
require_once "db.php";

// Ambil ID produk dari parameter GET
$id_produk = $_GET['id'];

try {
    // Hapus data dari tabel Stok terlebih dahulu
    $sql_stok = "DELETE FROM Stok WHERE id_produk = :id_produk";
    $stmt_stok = $conn->prepare($sql_stok);
    $stmt_stok->bindParam(":id_produk", $id_produk, PDO::PARAM_INT);
    $stmt_stok->execute();

    // Hapus data dari tabel Produk
    $sql_produk = "DELETE FROM Produk WHERE id_produk = :id_produk";
    $stmt_produk = $conn->prepare($sql_produk);
    $stmt_produk->bindParam(":id_produk", $id_produk, PDO::PARAM_INT);
    $stmt_produk->execute();

    // Cek apakah query berhasil
    if ($stmt_produk->rowCount() > 0) {
        echo json_encode(["success" => true]);
    } else {
        echo json_encode(["success" => false, "message" => "Gagal menghapus produk."]);
    }
} catch (PDOException $e) {
    echo json_encode(["success" => false, "message" => $e->getMessage()]);
}
?>