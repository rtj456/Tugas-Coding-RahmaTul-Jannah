<?php
require_once "db.php";

// Ambil data dari request POST
$data = json_decode(file_get_contents("php://input"), true);
$id_produk = $data['id_produk'];
$jumlah_stok = $data['jumlah_stok'];

try {
    // Query untuk memperbarui stok produk
    $sql = "UPDATE Stok SET jumlah_stok = :jumlah_stok WHERE id_produk = :id_produk";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(":jumlah_stok", $jumlah_stok, PDO::PARAM_INT);
    $stmt->bindParam(":id_produk", $id_produk, PDO::PARAM_INT);
    $stmt->execute();

    // Cek apakah query berhasil
    if ($stmt->rowCount() > 0) {
        echo json_encode(["success" => true]);
    } else {
        echo json_encode(["success" => false, "message" => "Gagal memperbarui stok."]);
    }
} catch (PDOException $e) {
    echo json_encode(["success" => false, "message" => $e->getMessage()]);
}
?>