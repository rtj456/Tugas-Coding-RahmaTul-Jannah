<?php
require_once "db.php";

try {
    // Query untuk mengambil data produk beserta stok
    $sql = "
        SELECT p.id_produk, p.nama_produk, p.harga, s.jumlah_stok 
        FROM Produk p 
        JOIN Stok s ON p.id_produk = s.id_produk
    ";
    $stmt = $conn->prepare($sql);
    $stmt->execute();
    $products = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Mengembalikan data dalam format JSON
    echo json_encode($products);
} catch (PDOException $e) {
    echo json_encode(["error" => $e->getMessage()]);
}
?>